import JobShop
from job import Job
from machine import Machine
import random
import simpy
import csv
import pandas as pd
from collections import deque
import matplotlib.pyplot as plt
from adjustText import adjust_text
from dispatchingrules import DispatchingRules
from torch.utils.tensorboard import SummaryWriter
from RL import LSTM_PPO
import datetime
import matplotlib.pyplot as plt
from matplotlib import pyplot
############  Global parameter settings  ###############

# Is machine failure allowed
CAN_BROKEN = True
# Is order insertion allowed
CAN_INSERT_JOB = True
# Reinforcement learning method used

DRL = LSTM_PPO(alpha_=0.001,state_dim=20,action_dim=8,fc1_dim=128,fc2_dim=64,fc3_dim=32,fc4_dim=16,ckpt_dir=None)

# Number of training steps
EPISODE = 8000
e=EPISODE

font1 = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 16,
}

#########################################
def creat_job(count, init_job_count, jobCount1=0, jobCount2=0, jobCount3=0):

    # Processing time
    process_time_list = [[100, 250, 240], [370, 300, 200], [120, 200, 230]]

    precedure_list = [[1, 2, 3], [1, 2, 3], [1, 2, 3]]
    joblist = []
    jobCount = count
    jobCount1 = random.randint(1, int(init_job_count / 3)) if jobCount1 == 0 else jobCount1
    jobCount2 = random.randint(1, int(init_job_count / 3)) if jobCount2 == 0 else jobCount2
    jobCount3 = init_job_count - jobCount1 - jobCount2 if jobCount3 == 0 else jobCount3

    for i in range(jobCount1):
        job = Job(0, 1, precedure_list[0], process_time_list[0], 0)
        joblist.append(job)
    for i in range(jobCount2):
        job = Job(0, 2, precedure_list[1], process_time_list[1], 0)
        joblist.append(job)
    for i in range(jobCount3):
        job = Job(0, 3, precedure_list[2], process_time_list[2], 0)
        joblist.append(job)
    for i, job in enumerate(joblist):
        job.job_id = i + 1

    return deque(joblist)


def gantt(flow, machinecount):
    colors = ['violet', 'brown', 'orange', 'red', 'purple', 'yellowgreen', 'deeppink', 'deepskyblue', 'lightseagreen',
              'gold']

    for j in range(machinecount):
        for i in range(len(flow[j])):
            width = flow[j][i]
            plt.barh(j + 1, width[3] - width[2], 0.5, left=width[2], facecolor=colors[width[0] % 10],
                     edgecolor='black')
            adjust_text(
                [plt.text(width[2] + 0.8, j + 0.85, 'J%s' % (width[0]), color="black", size=13)], )
    plt.show()


def creat_machine():
    rules = DispatchingRules()
    # 是否允许机器故障
    can_broken = 0
    m1 = Machine(env, 1, 1, 4, 1, rules, can_broken, DRL)
    m2 = Machine(env, 1, 2, 4, 1.2, rules, can_broken, DRL)
    m3 = Machine(env, 2, 3, 4, 1, rules, can_broken, DRL)
    m4 = Machine(env, 2, 4, 4, 0.9, rules, can_broken, DRL)
    m5 = Machine(env, 3, 5, 4, 1, rules, can_broken, DRL)
    m6 = Machine(env, 3, 6, 4, 1.3, rules, can_broken, DRL)
    lism = []
    lism.append(m1)
    lism.append(m2)
    lism.append(m3)
    lism.append(m4)
    lism.append(m5)
    lism.append(m6)
    # Machine classification number
    machine_number = {1: [1, 2], 2: [3, 4], 3: [5, 6]}
    return lism, machine_number


def run_jsp():
    global env, jobshop
    job_total_number = 20
    env = simpy.Environment()
    lisa = creat_job(job_total_number, 20, 4, 8, 8)
    lism, machine_number = creat_machine()
    jobshop = JobShop.JobShop(env, lisa, lism, machine_number, job_total_number, CAN_INSERT_JOB)
    env.run()
    flow = []
    makespan = 0
    for mac in lism:
        mac_process_list = mac.process_list
        print(mac_process_list)
        flow.append(mac_process_list)
        if len(mac_process_list) != 0:
            makespan = max(makespan, mac_process_list[-1][-1])
    print(makespan)
    return makespan,flow



def run():
    current_time=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    writer = SummaryWriter('./log/'+current_time)
    for episode in range(EPISODE):
        # The startup environment is initialized, the workpiece, the machine, but the algorithm is not initialized
        makespan,_=run_jsp()
        sum = DRL.sum
        DRL.reward_list.append(sum)
        DRL.sum = 0
        DRL.reward_prev = 0
        writer.add_scalar("reward", sum, global_step=episode)
        writer.add_scalar("maskespan", makespan, global_step=episode)
        print("---------------------------------")
        print(f"{episode}  ----  {sum}")
        print("---------------------------------")
    for i in range(len(DRL.loss_recorder)):
        writer.add_scalar('loss',DRL.loss_recorder[i],global_step=i)
    print(DRL.actions_recorder)
    reco=total(DRL.actions_recorder)
    print(reco)
    print("schedule over")
def run2():
    makespan1=100000
    flow1=[]

    current_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    #writer = SummaryWriter('./log/' + current_time)
    for episode in range(EPISODE):
        makespan,_=run_jsp()
        sum = DRL.sum
        DRL.reward_list.append(sum)
        mk = makespan
        m1 = []
        m1.append(mk)
        print(m1)
        DRL.sum = 0
        DRL.reward_prev = 0
        print("---------------------------------")
        print(DRL.reward_list)
        print("-----completion time---------")
        print(makespan)
        print("---------------------------------")

    for episod in range(200):
        makespan,flow=run_jsp()
        if makespan<makespan1:
            flow1=flow
            makespan1=makespan
    print(flow1)
    print(makespan1)
    gantt(flow1, machinecount=6)

def total(actions_recorder):
    totalsum=sum(actions_recorder)
    lis=[]
    for i,e in enumerate(actions_recorder):
        lis.append(e/totalsum)
    return lis
if __name__ == '__main__':
    run2()
